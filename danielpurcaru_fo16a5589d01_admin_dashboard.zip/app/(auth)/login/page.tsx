import LoginPage from "../loginPage/page";

 
  

export default function Login() {
  return (
    <div >
      <LoginPage/>
      
    </div>
  );
}
