 import AcademicCalendar from "@/components/Calendar";

export default function page() {
    return (
        <div className="w-full h-full">
            <AcademicCalendar />
        </div>
    )
}